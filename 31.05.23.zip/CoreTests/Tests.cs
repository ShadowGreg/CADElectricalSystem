﻿using System;
using NUnit.Framework;

namespace CoreTests {
    [TestFixture]
    public class Tests {
        [Test]
        public void Test1() {
            Assert.True(true);
        }
    }
}
﻿namespace CADElectricalSystem.Model.physicalQuantities;

public abstract class AReactivePower : IDoubleable
{
    protected AReactivePower(double value) : base(value)
    {
    }
}
﻿namespace CADElectricalSystem.Model.physicalQuantities;

public abstract class APower: IDoubleable
{
    protected APower(double value) : base(value)
    {
    }
}
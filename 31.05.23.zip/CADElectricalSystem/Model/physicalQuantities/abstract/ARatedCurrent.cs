﻿namespace CADElectricalSystem.Model.physicalQuantities;

public abstract class ARatedCurrent : IDoubleable
{
    protected ARatedCurrent(double value) : base(value)
    {
    }
}
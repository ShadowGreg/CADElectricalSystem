﻿namespace CADElectricalSystem.Model.physicalQuantities.Values;

public class RatedCurrent : ARatedCurrent
{
    public RatedCurrent(double value) : base(value)
    {
    }
}
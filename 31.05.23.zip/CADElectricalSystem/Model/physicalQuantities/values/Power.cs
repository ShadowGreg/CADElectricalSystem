﻿namespace CADElectricalSystem.Model.physicalQuantities.Values;

public class Power : APower
{
    public Power(double value) : base(value)
    {
    }
}
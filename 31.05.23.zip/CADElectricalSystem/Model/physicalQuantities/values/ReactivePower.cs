﻿namespace CADElectricalSystem.Model.physicalQuantities.Values;

public class ReactivePower : AReactivePower
{
    public ReactivePower(double value) : base(value)
    {
    }
}
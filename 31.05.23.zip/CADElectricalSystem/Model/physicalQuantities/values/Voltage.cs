﻿namespace CADElectricalSystem.Model.physicalQuantities.Values;

public class Voltage : AVoltage
{
    public Voltage(double value) : base(value)
    {
    }
}
﻿using System.Windows.Controls;

namespace WpfApp {
    public partial class RTMTable: Page {
        public RTMTable() {
            InitializeComponent();
        }
    }
}